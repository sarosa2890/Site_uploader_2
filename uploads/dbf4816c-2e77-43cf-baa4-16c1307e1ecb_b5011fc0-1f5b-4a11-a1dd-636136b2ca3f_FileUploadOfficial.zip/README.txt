
== FileUploadOfficial ==

📁 Локальный хостинг загрузки файлов с интерфейсом и доменом через DuckDNS

1. Убедитесь, что Python установлен (рекомендуется 3.11+)
2. Установите Flask: pip install flask
3. Запустите автообновление IP: дважды кликните duckdns_updater.bat
4. Запустите сервер: python app.py
5. Откройте сайт: http://fileuploadofficial.duckdns.org

Файлы загружаются и доступны по уникальной ссылке.
